# do2blehelix.github.io
The Handwritten Machine Learning Bible 

This repository contains my notes taken over the years in short explaining concepts as lucidly as possible for non data science background folks.
